
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Youtube, Instagram, Facebook } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Classes', href: '#classes' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'py-3 glass shadow-lg' : 'py-6 bg-transparent'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative">
            <div className="w-12 h-12 bg-[#FF6B6B] rounded-xl flex items-center justify-center text-white shadow-lg group-hover:rotate-12 transition-transform">
              <span className="font-artistic text-3xl">T</span>
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#4ECDC4] rounded-full border-2 border-white"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-[#2C3E50] leading-none">Art and Craft</span>
            <span className="text-xs font-bold text-[#FF6B6B] uppercase tracking-widest">with Tanay</span>
          </div>
        </motion.div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="relative text-sm font-bold text-[#2C3E50] hover:text-[#FF6B6B] transition-colors group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#FF6B6B] transition-all group-hover:w-full"></span>
            </a>
          ))}
          <motion.a 
            href="#contact"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-2.5 bg-[#2C3E50] text-white text-sm font-bold rounded-full hover:bg-[#FF6B6B] shadow-lg transition-all"
          >
            Enroll Now
          </motion.a>
        </div>

        {/* Instructor Profile */}
        <div className="flex items-center space-x-4">
          <div className="hidden lg:flex items-center space-x-2 mr-4 border-r pr-4 border-gray-200">
             <a href="https://www.youtube.com/@artandcraftwithtanoy" target="_blank" className="p-2 hover:bg-[#FF6B6B]/10 rounded-full text-[#2C3E50] transition-colors"><Youtube size={18} /></a>
             <a href="#" className="p-2 hover:bg-[#FF6B6B]/10 rounded-full text-[#2C3E50] transition-colors"><Instagram size={18} /></a>
          </div>

          <div className="relative group">
            <motion.div 
              whileHover={{ scale: 1.1, rotate: 5 }}
              className="w-12 h-12 rounded-full p-1 bg-gradient-to-tr from-[#FF6B6B] via-[#FFE66D] to-[#4ECDC4] shadow-xl cursor-pointer overflow-visible"
            >
              <div className="w-full h-full rounded-full overflow-hidden border-2 border-white bg-white">
                <img 
                  src="https://raw.githubusercontent.com/tanay-art/assets/main/tanay_instructor.png" 
                  alt="Tanay" 
                  className="w-full h-full object-cover object-top" 
                  onError={(e) => { 
                    (e.currentTarget as HTMLImageElement).src = 'https://picsum.photos/seed/artist/200';
                  }} 
                />
              </div>
            </motion.div>
            <div className="absolute right-0 top-16 w-56 glass p-4 rounded-2xl shadow-2xl opacity-0 group-hover:opacity-100 transition-all invisible group-hover:visible translate-y-2 group-hover:translate-y-0 duration-300 pointer-events-none text-center">
               <p className="font-bold text-sm text-[#2C3E50]">Tanay (Lead Instructor)</p>
               <p className="text-[10px] text-[#FF6B6B] font-bold uppercase mb-2">Master Artist | Kolkata</p>
               <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
                  <div className="w-4/5 h-full bg-[#FF6B6B]"></div>
               </div>
            </div>
          </div>

          <button className="md:hidden p-2 text-[#2C3E50]" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-white shadow-2xl md:hidden p-8 flex flex-col items-center space-y-6"
          >
             {navLinks.map((link) => (
                <a key={link.name} href={link.href} onClick={() => setIsMobileMenuOpen(false)} className="text-xl font-bold text-[#2C3E50] hover:text-[#FF6B6B]">
                  {link.name}
                </a>
              ))}
              <div className="flex space-x-6 pt-6 border-t w-full justify-center">
                <Youtube size={24} />
                <Instagram size={24} />
                <Facebook size={24} />
              </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
