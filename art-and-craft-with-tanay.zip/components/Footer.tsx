
import React from 'react';
import { Instagram, Youtube, Facebook, Mail, Phone, MapPin, Heart, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-100 pt-32 pb-16">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-20 mb-24">
          <div className="space-y-8">
             <motion.div 
               whileHover={{ scale: 1.05 }}
               className="flex items-center space-x-3"
             >
                <div className="w-12 h-12 bg-[#FF6B6B] rounded-2xl flex items-center justify-center text-white font-artistic text-3xl shadow-xl">T</div>
                <div className="flex flex-col">
                  <span className="text-xl font-black leading-none">Tanay Art</span>
                  <span className="text-[10px] text-[#FF6B6B] font-black uppercase tracking-widest">Kolkata Studio</span>
                </div>
             </motion.div>
             <p className="text-gray-400 font-medium leading-relaxed">
               Nurturing the next generation of creative minds in the cultural capital of India. From heritage folk art to digital innovation.
             </p>
             <div className="flex space-x-5">
                {[
                  { icon: <Facebook />, link: "#" },
                  { icon: <Youtube />, link: "https://www.youtube.com/@artandcraftwithtanoy" },
                  { icon: <Instagram />, link: "#" }
                ].map((social, i) => (
                  <motion.a 
                    key={i}
                    href={social.link} 
                    whileHover={{ y: -5, scale: 1.1 }}
                    className="w-12 h-12 rounded-[1.2rem] bg-gray-50 flex items-center justify-center text-gray-400 hover:bg-[#FF6B6B] hover:text-white transition-all shadow-lg"
                  >
                    {social.icon}
                  </motion.a>
                ))}
             </div>
          </div>

          <div>
             <h4 className="font-black text-xl mb-10 text-[#2C3E50]">Exploration</h4>
             <ul className="space-y-5">
                {['Home', 'About Us', 'Art Classes', 'Student Gallery', 'Contact'].map(link => (
                  <li key={link}>
                    <a href={`#${link.toLowerCase().replace(' ', '')}`} className="text-gray-400 font-bold hover:text-[#FF6B6B] transition-all flex items-center group">
                      <span className="mr-2 opacity-0 group-hover:opacity-100 transition-all">-</span>
                      {link}
                      <ArrowUpRight size={14} className="ml-2 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                    </a>
                  </li>
                ))}
             </ul>
          </div>

          <div>
             <h4 className="font-black text-xl mb-10 text-[#2C3E50]">Studio Info</h4>
             <ul className="space-y-5">
                {['Anatomy Tutorials', 'Workshop Schedule', 'Traditional Crafts', 'Exhibition News'].map(link => (
                  <li key={link}>
                    <a href="#" className="text-gray-400 font-bold hover:text-[#FF6B6B] transition-all flex items-center group">
                      {link}
                    </a>
                  </li>
                ))}
             </ul>
          </div>

          <div>
             <h4 className="font-black text-xl mb-10 text-[#2C3E50]">Join The Canvas</h4>
             <p className="text-gray-400 font-medium mb-8">Receive weekly art challenges and Kolkata studio updates.</p>
             <div className="space-y-3">
                <input 
                  type="email" 
                  placeholder="Artist Email" 
                  className="w-full bg-gray-50 border-2 border-transparent rounded-2xl px-6 py-4 text-sm font-bold focus:border-[#FF6B6B] focus:bg-white outline-none transition-all"
                />
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-[#2C3E50] text-white py-4 rounded-2xl font-black shadow-xl hover:bg-black transition-all"
                >
                  Join Community
                </motion.button>
             </div>
          </div>
        </div>

        <div className="border-t border-gray-100 pt-12 flex flex-col md:flex-row items-center justify-between text-gray-400 font-bold text-sm">
           <p>© {new Date().getFullYear()} Art and Craft with Tanay. All rights reserved.</p>
           <p className="flex items-center mt-6 md:mt-0">
             Crafted with <Heart size={16} className="mx-2 text-[#FF6B6B] fill-current animate-pulse" /> in Kolkata
           </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
