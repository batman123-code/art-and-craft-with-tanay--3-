
import { GoogleGenAI } from "@google/genai";

// getArtTip generates a quick art or craft tip using Gemini.
// Following @google/genai guidelines: instantiating client right before the call.
export const getArtTip = async (topic?: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: topic ? `Give me a quick art tip about ${topic}. Keep it under 2 sentences.` : "Give me a daily quick art or craft tip. Keep it under 2 sentences.",
      config: {
        temperature: 0.8,
        systemInstruction: "You are an expert art instructor named Tanay based in Kolkata, India. You are encouraging, creative, and professional. Mention Indian art styles like Madhubani or Warli occasionally.",
      },
    });
    // Extracting text using the .text property as per guidelines.
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Keep practicing and let your imagination flow! Art is a journey, not just a destination.";
  }
};

// chatWithTanay allows a chat-like interaction with the instructor persona.
export const chatWithTanay = async (message: string) => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: message,
          config: {
            temperature: 0.7,
            systemInstruction: "You are Tanay, the lead instructor at Tanay Art Classes in Kolkata. You teach kids and adults painting, sketching, and traditional Indian crafts. Be helpful, enthusiastic, and talk about art techniques when relevant. Use a warm, culturally respectful tone.",
          },
        });
        return response.text;
      } catch (error) {
        console.error("Gemini Chat Error:", error);
        return "I'm a bit busy with my canvas in the studio right now! Please contact me via the form or WhatsApp for details.";
      }
};
