
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageCircle, Sparkles } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '', class: 'painting' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
    setFormData({ name: '', email: '', message: '', class: 'painting' });
  };

  return (
    <section id="contact" className="py-32 bg-[#F8F9FA] relative overflow-hidden perspective-2000">
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
         <div className="absolute top-1/4 -left-20 w-96 h-96 border-4 border-[#FF6B6B] rounded-full" />
         <div className="absolute bottom-1/4 -right-20 w-[500px] h-[500px] border-4 border-[#4ECDC4] rounded-full" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          {/* Info Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center space-x-3 px-6 py-2 bg-white rounded-full shadow-lg text-[#FF6B6B] font-black text-[10px] mb-10 uppercase tracking-widest">
              <Sparkles size={14} />
              <span>Get In Touch</span>
            </div>
            
            <h2 className="text-5xl lg:text-7xl font-black mb-10 text-[#2C3E50] leading-[1.1]">
              Let's Start Your <br /><span className="text-[#FF6B6B]">Creative Chapter</span>
            </h2>
            
            <p className="text-gray-500 text-xl mb-12 max-w-lg leading-relaxed font-medium">
              Join us at our Salt Lake studio for a coffee and a canvas. We are here to answer all your artistic queries.
            </p>

            <div className="grid gap-10">
              {[
                { icon: <Phone />, title: "Call Mentor", val: "+91 91234 56789", color: "#FF6B6B" },
                { icon: <Mail />, title: "Art Support", val: "hello@tanayart.com", color: "#4ECDC4" },
                { icon: <MapPin />, title: "Salt Lake Studio", val: "Sector V, Kolkata, 700091", color: "#9B59B6" }
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  whileHover={{ x: 15, scale: 1.02 }}
                  className="flex items-center space-x-6 group"
                >
                  <div 
                    style={{ backgroundColor: `${item.color}15`, color: item.color }}
                    className="w-16 h-16 rounded-[1.5rem] flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform"
                  >
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-black text-[#2C3E50] text-lg leading-none mb-2">{item.title}</h4>
                    <p className="text-gray-400 font-bold">{item.val}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-16 rounded-[4rem] overflow-hidden shadow-3xl h-80 border-[12px] border-white transform hover:scale-[1.02] transition-transform cursor-none clickable">
               <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.3411030043183!2d88.4316!3d22.5726!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0275051f886073%3A0x396994c6553856c!2sSalt%20Lake%20Sector%20V%2C%20Kolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
                width="100%" height="100%" style={{ border: 0, filter: "grayscale(1) contrast(1.2) brightness(0.9)" }} allowFullScreen loading="lazy" 
               />
            </div>
          </motion.div>

          {/* Form Side - Styled like a 3D Floating Paper */}
          <motion.div
            initial={{ opacity: 0, x: 80, rotateY: 15 }}
            whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            viewport={{ once: true }}
            className="bg-white p-12 lg:p-16 rounded-[4rem] shadow-[0_80px_160px_rgba(0,0,0,0.08)] relative overflow-hidden border border-gray-100 transform-gpu hover:shadow-2xl transition-shadow"
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Paper Texture and Glare */}
            <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/handmade-paper.png')" }} />

            {submitted && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-white z-20 flex flex-col items-center justify-center text-center p-12"
              >
                <div className="w-24 h-24 bg-green-100 text-green-500 rounded-full flex items-center justify-center mb-8 shadow-inner">
                   <Send size={48} />
                </div>
                <h3 className="text-4xl font-black mb-4">Message Sent!</h3>
                <p className="text-gray-500 text-xl font-medium">Tanay will connect with you via WhatsApp soon.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-12 px-10 py-4 bg-[#FF6B6B] text-white rounded-2xl font-black shadow-2xl"
                >
                  Send Another
                </button>
              </motion.div>
            )}

            <div className="relative z-10 translate-z-20">
              <h3 className="text-3xl font-black mb-10 text-[#2C3E50]">Start Your Creative Journey</h3>
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400">Full Name</label>
                    <input 
                      required
                      type="text" 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      placeholder="e.g. Rahul Sen" 
                      className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-[#FF6B6B] focus:bg-white outline-none transition-all font-bold"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="block text-xs font-black uppercase tracking-widest text-gray-400">Email Address</label>
                    <input 
                      required
                      type="email" 
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      placeholder="rahul@art.com" 
                      className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-[#FF6B6B] focus:bg-white outline-none transition-all font-bold"
                    />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-400">Art Discipline</label>
                  <select 
                     value={formData.class}
                     onChange={e => setFormData({...formData, class: e.target.value})}
                     className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-[#FF6B6B] focus:bg-white outline-none transition-all font-black appearance-none"
                  >
                    <option value="indian-folk">Traditional Folk Art</option>
                    <option value="watercolor">Watercolor Landscapes</option>
                    <option value="sketching">Anatomy Sketching</option>
                    <option value="crafts">Eco-Friendly Sculpting</option>
                  </select>
                </div>

                <div className="space-y-3">
                  <label className="block text-xs font-black uppercase tracking-widest text-gray-400">Your Vision</label>
                  <textarea 
                    required
                    rows={4}
                    value={formData.message}
                    onChange={e => setFormData({...formData, message: e.target.value})}
                    placeholder="Tell us what you want to create..." 
                    className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-3xl focus:border-[#FF6B6B] focus:bg-white outline-none transition-all font-bold resize-none"
                  />
                </div>

                <motion.button 
                  type="submit"
                  whileHover={{ scale: 1.02, translateZ: 20 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-6 bg-[#FF6B6B] text-white rounded-3xl font-black shadow-3xl shadow-[#FF6B6B]/40 flex items-center justify-center space-x-4 text-xl"
                >
                  <span>Begin Journey</span>
                  <Send size={24} />
                </motion.button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
