
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, Sparkles, X, User } from 'lucide-react';
import { getArtTip, chatWithTanay } from '../services/geminiService';

const AIArtAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([
    { role: 'ai', text: "Namaste! I'm Tanay's AI assistant. Want an art tip or have questions about our Kolkata batches?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [dailyTip, setDailyTip] = useState("");

  useEffect(() => {
    const fetchTip = async () => {
      const tip = await getArtTip();
      setDailyTip(tip || "");
    };
    fetchTip();
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput("");
    setLoading(true);
    
    const aiResponse = await chatWithTanay(userMsg);
    setMessages(prev => [...prev, { role: 'ai', text: aiResponse || "I'm busy at the studio, ask again soon!" }]);
    setLoading(false);
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-6 w-14 h-14 bg-[#9B59B6] text-white rounded-full shadow-2xl flex items-center justify-center z-40 hover:bg-[#8e44ad] transition-colors"
      >
        <Sparkles size={28} />
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.8 }}
            className="fixed bottom-6 right-6 w-[90vw] md:w-[400px] h-[500px] bg-white rounded-2xl shadow-3xl z-50 flex flex-col overflow-hidden border border-gray-100"
          >
            {/* Header */}
            <div className="bg-[#9B59B6] p-4 flex justify-between items-center text-white">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full border-2 border-white/50 overflow-hidden bg-white">
                   <img 
                    src="https://raw.githubusercontent.com/tanay-art/assets/main/tanay_instructor.png" 
                    alt="Tanay Assistant" 
                    className="w-full h-full object-cover object-top"
                    onError={(e) => { (e.currentTarget as HTMLImageElement).src = 'https://picsum.photos/seed/tanay/200'; }}
                   />
                </div>
                <div>
                  <h4 className="font-bold text-sm">Tanay AI Mentor</h4>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-[10px] opacity-80">Online & Ready</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)}><X size={20}/></button>
            </div>

            {/* Chat Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${m.role === 'user' ? 'bg-[#9B59B6] text-white rounded-tr-none' : 'bg-white border border-gray-200 text-[#2C3E50] rounded-tl-none'}`}>
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                   <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-tl-none">
                      <div className="flex space-x-1">
                         <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                         <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                         <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                      </div>
                   </div>
                </div>
              )}
            </div>

            {/* Daily Tip Snippet */}
            {dailyTip && (
                <div className="px-4 py-2 bg-[#FFE66D]/20 text-[#E67E22] text-[11px] font-bold border-t border-[#FFE66D]/40">
                    💡 Art Tip: {dailyTip}
                </div>
            )}

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-100 flex items-center space-x-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about art batches..."
                className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#9B59B6]/50"
              />
              <button 
                onClick={handleSend}
                disabled={loading}
                className="w-10 h-10 bg-[#9B59B6] text-white rounded-full flex items-center justify-center hover:bg-[#8e44ad] transition-all disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIArtAssistant;
