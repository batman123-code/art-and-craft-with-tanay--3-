
import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { CheckCircle2, MapPin, Award, Heart } from 'lucide-react';
import { MandalaSVG } from '../constants';

const About: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);

  const highlights = [
    { title: "Tradition", desc: "Indian Folk Heritage", icon: <Award size={18} /> },
    { title: "Community", desc: "All Age Groups Welcome", icon: <Heart size={18} /> },
    { title: "Expertise", desc: "15+ Years Experience", icon: <CheckCircle2 size={18} /> },
    { title: "Location", desc: "Heart of Kolkata", icon: <MapPin size={18} /> }
  ];

  return (
    <section id="about" className="py-32 bg-white overflow-hidden relative">
      <motion.div 
        style={{ rotate }}
        className="absolute -left-40 top-0 w-[800px] h-[800px] pointer-events-none opacity-5"
      >
        <MandalaSVG className="w-full h-full" color="#FF6B6B" />
      </motion.div>
      
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -80 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: "easeOut" as const }}
            viewport={{ once: true, margin: "-100px" }}
            className="relative"
            style={{ transformStyle: "preserve-3d", perspective: "1500px" }}
          >
            {/* 3D Stacked Image Effect */}
            <div className="relative z-10 p-3 bg-white rounded-[3.5rem] shadow-3xl border border-gray-50 overflow-hidden transform hover:translate-z-10 transition-transform">
              <img 
                src="https://raw.githubusercontent.com/tanay-art/assets/main/tanay_instructor.png" 
                alt="Tanay Art Mentor" 
                className="rounded-[2.5rem] w-full h-[650px] object-cover object-top"
                onError={(e) => { (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?q=80&w=800&auto=format&fit=crop'; }}
              />
            </div>
            
            {/* Decorative Offset Squares */}
            <motion.div 
              animate={{ rotate: 12, y: [0, 15, 0] }}
              transition={{ duration: 6, repeat: Infinity }}
              className="absolute -bottom-10 -right-10 w-72 h-72 bg-[#FFE66D] rounded-[4rem] -z-10 opacity-30 blur-2xl"
            />
            <motion.div 
              animate={{ rotate: -8, x: [0, -15, 0] }}
              transition={{ duration: 8, repeat: Infinity }}
              className="absolute -top-10 -left-10 w-64 h-64 bg-[#4ECDC4] rounded-[3rem] -z-10 opacity-20 blur-xl"
            />
            
            <div className="absolute top-1/2 -right-12 z-20 glass p-6 rounded-3xl shadow-2xl translate-z-20">
               <p className="text-4xl font-black text-[#FF6B6B]">15+</p>
               <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none">Years Expertise</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 80 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: "easeOut" as const }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="flex items-center space-x-3 text-[#FF6B6B] font-black uppercase tracking-[0.4em] text-xs mb-8">
               <div className="w-8 h-[2px] bg-[#FF6B6B]" />
               <span>Meet Your Mentor</span>
            </div>
            
            <h2 className="text-5xl lg:text-7xl font-black mb-8 text-[#2C3E50] leading-[1.1]">
              Crafting Dreams In The <span className="text-[#FF6B6B]">City of Joy</span>
            </h2>
            
            <p className="text-gray-500 mb-8 text-xl leading-relaxed font-medium">
              Based in the pulsating heart of Kolkata, <span className="text-[#2C3E50] font-black">Art and Craft with Tanay</span> is where legacy meets modern strokes. 
            </p>
            
            <p className="text-gray-400 mb-12 text-lg leading-relaxed">
              We don't just teach art; we nurture the artistic soul. Whether you are picking up a brush for the first time or looking to master the intricate patterns of Pattachitra, our studio provides the perfect atmospheric sanctuary.
            </p>

            <div className="grid sm:grid-cols-2 gap-8">
              {highlights.map((item, idx) => (
                <motion.div 
                  key={idx} 
                  whileHover={{ x: 10, scale: 1.05 }}
                  className="flex items-start space-x-5 group"
                >
                  <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-[#FF6B6B] group-hover:bg-[#FF6B6B] group-hover:text-white transition-all shadow-lg shadow-black/5">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-black text-[#2C3E50] mb-1">{item.title}</h4>
                    <p className="text-sm text-gray-400 font-bold">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.button 
              whileHover={{ scale: 1.05, translateZ: 20 }}
              whileTap={{ scale: 0.95 }}
              className="mt-16 px-12 py-6 bg-[#2C3E50] text-white rounded-[2rem] font-black hover:bg-black transition-all shadow-3xl shadow-[#2C3E50]/20"
            >
              The Full Story
            </motion.button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
