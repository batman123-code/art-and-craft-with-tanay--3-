
import React from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { ChevronRight, Sparkles, Play } from 'lucide-react';
import { BrushStrokeSVG, PaintSplatterSVG, MandalaSVG } from '../constants';

const Hero: React.FC = () => {
  const { scrollY } = useScroll();
  
  const y1 = useTransform(scrollY, [0, 1000], [0, 500]);
  const y2 = useTransform(scrollY, [0, 1000], [0, -400]);
  const rotate = useTransform(scrollY, [0, 1000], [0, 120]);
  const scale = useTransform(scrollY, [0, 600], [1, 0.75]);
  const opacity = useTransform(scrollY, [0, 600], [1, 0]);

  const springY1 = useSpring(y1, { stiffness: 40, damping: 15 });
  const springY2 = useSpring(y2, { stiffness: 40, damping: 15 });

  // Fixed: Cast "easeOut" as const to prevent TypeScript from inferring it as a generic string,
  // which is incompatible with Framer Motion's Easing literal union type.
  const textVariants = {
    hidden: { opacity: 0, y: 50, rotateX: 45 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: { delay: 0.1 * i, duration: 0.8, ease: "easeOut" as const }
    })
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden bg-[#FDFBF7]">
      {/* 3D Decorative Layers */}
      <motion.div style={{ y: springY1, rotate, opacity: 0.08 }} className="absolute top-20 -right-60 pointer-events-none">
        <MandalaSVG className="w-[1000px] h-[1000px]" color="#FF6B6B" />
      </motion.div>
      
      <motion.div style={{ y: springY2, opacity: 0.12 }} className="absolute -bottom-40 -left-40 pointer-events-none">
        <PaintSplatterSVG className="w-[800px] h-[800px]" color="#4ECDC4" />
      </motion.div>

      {/* Floating Art Supplies (3D Icons) */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: 0.2, 
            y: [0, -20, 0],
            rotate: [0, 10 * (i + 1), 0],
            x: [0, 10 * (i - 2), 0]
          }}
          transition={{ 
            duration: 4 + i, 
            repeat: Infinity, 
            ease: "easeInOut",
            delay: i * 0.5 
          }}
          className="absolute hidden lg:block text-4xl pointer-events-none select-none"
          style={{
            top: `${15 + i * 15}%`,
            left: `${10 + i * 20}%`,
            zIndex: 5
          }}
        >
          {['🎨', '🖌️', '🖍️', '✏️', '🎭'][i]}
        </motion.div>
      ))}

      <div className="container mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center relative z-10">
        <motion.div style={{ scale, opacity }}>
          <motion.div 
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", delay: 0.4 }}
            className="inline-flex items-center space-x-3 px-6 py-2 bg-white/60 backdrop-blur-md rounded-full shadow-xl text-[#FF6B6B] font-bold text-[10px] mb-10 border border-white/40"
          >
            <Sparkles size={16} className="text-[#FFE66D]" />
            <span className="uppercase tracking-[0.3em]">Nurturing the Artist Within</span>
          </motion.div>
          
          <h1 className="text-6xl lg:text-[8rem] font-black leading-[0.85] mb-10 text-[#2C3E50] perspective-1000">
            {["Paint", "Your", "Soul"].map((word, i) => (
              <motion.span 
                key={word} 
                custom={i} 
                variants={textVariants} 
                initial="hidden" 
                animate="visible"
                className="block relative"
              >
                {word === "Soul" ? (
                  <span className="relative inline-block text-[#FF6B6B]">
                    {word}
                    <BrushStrokeSVG className="absolute -bottom-10 left-0 w-full opacity-40 h-14" color="#FFE66D" />
                  </span>
                ) : word}
              </motion.span>
            ))}
          </h1>
          
          <p className="text-xl text-gray-500 mb-12 max-w-lg leading-relaxed font-medium">
            Discover the magic of <span className="text-[#4ECDC4] font-bold">Kolkata's finest art mentoring</span>. From traditional heritage to modern digital canvasing.
          </p>
          
          <div className="flex flex-col sm:flex-row space-y-5 sm:space-y-0 sm:space-x-8">
            <motion.a 
              href="#contact"
              whileHover={{ scale: 1.05, translateZ: 20, boxShadow: "0 25px 50px rgba(255, 107, 107, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              className="px-14 py-6 bg-[#FF6B6B] text-white rounded-3xl font-black shadow-2xl flex items-center justify-center space-x-4 transition-all"
            >
              <span>Enroll Today</span>
              <ChevronRight size={22} />
            </motion.a>
            <motion.a 
              href="https://www.youtube.com/@artandcraftwithtanoy"
              target="_blank"
              whileHover={{ scale: 1.05, translateZ: 10, borderColor: "#FF6B6B" }}
              className="px-14 py-6 bg-white/40 backdrop-blur-sm text-[#2C3E50] border-2 border-gray-100 rounded-3xl font-black flex items-center justify-center space-x-4 transition-all"
            >
              <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
                 <Play size={18} className="text-white fill-current ml-1" />
              </div>
              <span>Tutorials</span>
            </motion.a>
          </div>
        </motion.div>

        <div className="relative lg:h-[750px] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotateY: -30, rotateX: 10 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0, rotateX: 0 }}
            transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-20 group"
            style={{ transformStyle: "preserve-3d", perspective: "2000px" }}
          >
            <motion.div 
              whileHover={{ rotateY: 8, rotateX: -4, translateZ: 50 }}
              className="p-4 bg-white rounded-[5rem] shadow-[0_60px_120px_rgba(0,0,0,0.12)] border border-gray-100"
            >
               <img 
                src="https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?auto=format&fit=crop&q=80&w=1200" 
                alt="Artist working"
                className="w-full h-[550px] lg:h-[650px] object-cover rounded-[4rem]"
              />
            </motion.div>
            
            {/* 3D Dynamic Elements */}
            <motion.div 
              animate={{ y: [0, -30, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-16 -right-16 glass p-10 rounded-[3rem] shadow-3xl z-30 border-white/60"
            >
              <span className="text-6xl block mb-3">🎨</span>
              <p className="text-[12px] font-black uppercase tracking-[0.3em] text-[#FF6B6B]">Heritage Art</p>
            </motion.div>

            <motion.div 
              animate={{ x: [0, 40, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-20 -left-24 glass p-8 rounded-[3rem] shadow-3xl z-30 hidden md:block border-white/60"
            >
              <div className="flex items-center space-x-5">
                 <div className="w-16 h-16 bg-[#4ECDC4]/20 rounded-[1.5rem] flex items-center justify-center text-4xl">🧿</div>
                 <div>
                    <p className="text-lg font-black text-[#2C3E50]">Bengali Roots</p>
                    <p className="text-[10px] text-[#4ECDC4] font-bold uppercase tracking-widest">Cultural Hub</p>
                 </div>
              </div>
            </motion.div>
          </motion.div>

          <div className="absolute inset-0 -z-10 flex items-center justify-center overflow-visible">
             <motion.div 
              animate={{ scale: [1, 1.4, 1], rotate: [0, 180, 360] }}
              transition={{ duration: 25, repeat: Infinity }}
              className="w-[140%] h-[140%] bg-gradient-to-tr from-[#FF6B6B]/10 via-[#FFE66D]/10 to-[#4ECDC4]/10 rounded-full blur-[150px]" 
             />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
