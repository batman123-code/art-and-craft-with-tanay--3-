
import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform, AnimatePresence } from 'framer-motion';
import { ART_CLASSES } from '../constants';
import { ArrowRight, RotateCw, Info, CheckCircle2 } from 'lucide-react';

const ClassCard: React.FC<{ artClass: typeof ART_CLASSES[0] }> = ({ artClass }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // 3D Tilt Values
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  // We only tilt the front face. When flipped, we keep it stable at 180deg.
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["15deg", "-15deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-15deg", "15deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current || isFlipped) return;
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const toggleFlip = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFlipped(!isFlipped);
    // Reset tilt when flipping
    x.set(0);
    y.set(0);
  };

  return (
    <div 
      ref={cardRef}
      className="relative h-[520px] w-full cursor-none perspective-2000 clickable"
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <motion.div
        style={{ 
          rotateX: isFlipped ? 0 : rotateX,
          rotateY: isFlipped ? 180 : rotateY,
          transformStyle: "preserve-3d" 
        }}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.8, type: "spring", stiffness: 260, damping: 20 }}
        className="w-full h-full relative"
      >
        {/* Front Face */}
        <div 
          className="absolute inset-0 backface-hidden rounded-[3rem] bg-white p-4 shadow-2xl border border-gray-100 overflow-hidden" 
          style={{ transform: "translateZ(0px)" }}
        >
          <div className="h-full w-full rounded-[2.5rem] overflow-hidden relative group">
            <img 
              src={artClass.image} 
              alt={artClass.title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-90" 
            />
            
            {/* Glossy Overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-black/80 via-black/20 to-transparent pointer-events-none" />

            <div className="absolute inset-0 flex flex-col justify-end p-8" style={{ transform: "translateZ(50px)" }}>
              <motion.div 
                style={{ transform: "translateZ(60px)" }}
                className="mb-4"
              >
                <span className="px-4 py-2 bg-[#FF6B6B] text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-full shadow-xl">
                  {artClass.category}
                </span>
              </motion.div>
              
              <h3 className="text-3xl font-black text-white mb-2 leading-tight drop-shadow-lg" style={{ transform: "translateZ(80px)" }}>
                {artClass.title}
              </h3>

              <div className="flex justify-between items-center mt-4" style={{ transform: "translateZ(90px)" }}>
                <span className="text-[#FFE66D] font-black text-2xl drop-shadow-md">
                  {artClass.price}
                </span>
                
                <button 
                  onClick={toggleFlip}
                  className="w-14 h-14 bg-white/20 backdrop-blur-xl border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-[#FF6B6B] hover:border-[#FF6B6B] transition-all group/btn"
                >
                  <RotateCw size={24} className="group-hover/btn:rotate-180 transition-transform duration-500" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Back Face (Details) */}
        <div 
          className="absolute inset-0 backface-hidden rounded-[3rem] bg-[#2C3E50] p-10 shadow-2xl flex flex-col items-center justify-center text-center border-4 border-[#FF6B6B]/20"
          style={{ transform: "rotateY(180deg) translateZ(1px)" }}
        >
          <div className="mb-6 w-20 h-20 bg-[#FF6B6B]/10 rounded-3xl flex items-center justify-center text-[#FF6B6B]" style={{ transform: "translateZ(60px)" }}>
            <Info size={40} />
          </div>
          
          <h3 className="text-3xl font-black text-white mb-4" style={{ transform: "translateZ(80px)" }}>
            Course Intel
          </h3>
          
          <div className="space-y-3 mb-10 text-left w-full" style={{ transform: "translateZ(40px)" }}>
             {['Personal Mentorship', 'Live Demos', 'Certification'].map((feature, i) => (
               <div key={i} className="flex items-center space-x-3 text-gray-300 text-sm font-medium">
                 <CheckCircle2 size={16} className="text-[#4ECDC4]" />
                 <span>{feature}</span>
               </div>
             ))}
          </div>

          <p className="text-gray-400 text-xs leading-relaxed mb-10 italic" style={{ transform: "translateZ(30px)" }}>
            {artClass.description}
          </p>

          <div className="w-full space-y-4" style={{ transform: "translateZ(100px)" }}>
             <button className="w-full py-5 bg-[#FF6B6B] text-white rounded-2xl font-black shadow-2xl shadow-[#FF6B6B]/40 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center space-x-3 group">
                <span>Secure Spot</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
             </button>
             
             <button 
                onClick={toggleFlip}
                className="text-[#4ECDC4] font-bold text-xs uppercase tracking-widest hover:text-white transition-colors"
             >
               Go Back
             </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const ArtClassesSection: React.FC = () => {
  return (
    <section id="classes" className="py-32 bg-[#F8F9FA] overflow-hidden relative">
      {/* Decorative BG element */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-[#FF6B6B]/5 to-transparent rounded-full blur-[100px] -z-10" />

      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-20 gap-10">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="max-w-xl"
          >
             <span className="text-[#4ECDC4] font-black uppercase tracking-[0.4em] text-xs mb-6 block">Unlock Your Talent</span>
             <h2 className="text-5xl md:text-7xl font-black leading-[0.9] text-[#2C3E50]">
              Explore Our <br />
              <span className="text-[#FF6B6B] inline-block mt-2">Masterclasses</span>
            </h2>
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-gray-500 text-xl max-w-sm leading-relaxed font-medium"
          >
            A curated curriculum designed to take you from a curious beginner to a confident artist in the heart of Kolkata.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 xl:gap-12">
          {ART_CLASSES.map((ac, idx) => (
            <motion.div
              key={ac.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1, duration: 0.6 }}
              viewport={{ once: true }}
            >
              <ClassCard artClass={ac} />
            </motion.div>
          ))}
        </div>
      </div>
      
      <style>{`
        .perspective-2000 { perspective: 2000px; }
        .backface-hidden { backface-visibility: hidden; }
      `}</style>
    </section>
  );
};

export default ArtClassesSection;
