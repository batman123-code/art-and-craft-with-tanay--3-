
import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Youtube, ExternalLink, Play, Users, Bell } from 'lucide-react';
import { YouTubeVideo } from '../types';

const VideoCard = ({ video, large = false }: { video: YouTubeVideo, large?: boolean }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const xSpring = useSpring(x);
  const ySpring = useSpring(y);
  
  const rotateX = useTransform(ySpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(xSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMove = (e: React.MouseEvent) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (rect) {
      x.set((e.clientX - rect.left) / rect.width - 0.5);
      y.set((e.clientY - rect.top) / rect.height - 0.5);
    }
  };

  const handleLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className={`relative group rounded-[3rem] overflow-hidden shadow-3xl bg-[#2C3E50] ${large ? 'md:col-span-2 md:h-80' : 'h-72'} cursor-none clickable`}
    >
      <img 
        src={video.thumb} 
        alt={video.title} 
        className="w-full h-full object-cover opacity-40 group-hover:opacity-100 transition-all duration-700 group-hover:scale-110" 
      />
      
      {/* 3D Glare */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="absolute inset-0 flex items-center justify-center translate-z-10">
         <motion.div 
          whileHover={{ scale: 1.2, rotate: 15 }}
          className="w-20 h-20 bg-white/10 backdrop-blur-xl border border-white/30 rounded-full flex items-center justify-center group-hover:bg-red-600 transition-all shadow-2xl"
         >
            <Play className="text-white fill-current ml-1" size={32} />
         </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 w-full p-10 bg-gradient-to-t from-black via-black/40 to-transparent translate-z-20">
         <div className="flex items-center space-x-3 mb-2">
            <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse" />
            <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em]">{video.views} Views</p>
         </div>
         <h4 className="font-black text-2xl text-white leading-tight drop-shadow-2xl">{video.title}</h4>
      </div>
    </motion.div>
  );
};

const YouTubeSection: React.FC = () => {
  const channelUrl = "https://www.youtube.com/@artandcraftwithtanoy";
  
  const featuredVideos: YouTubeVideo[] = [
    { id: '1', title: 'Perfect Watercolor Clouds', thumb: 'https://images.unsplash.com/photo-1541119638723-c51cbe2262aa?q=80&w=800&auto=format&fit=crop', views: '12K+' },
    { id: '2', title: 'Madhubani Secret Shading', thumb: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?q=80&w=800&auto=format&fit=crop', views: '8.4K' },
    { id: '3', title: 'Sketching Like a Pro', thumb: 'https://images.unsplash.com/photo-1503642551022-c0111b59558a?q=80&w=800&auto=format&fit=crop', views: '15.2K' },
  ];

  return (
    <section className="py-32 bg-[#1A1F2C] text-white relative overflow-hidden perspective-2000">
      <motion.div 
        animate={{ x: [-100, 100, -100], y: [-50, 50, -50], rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
        className="absolute top-0 right-0 w-[800px] h-[800px] bg-red-600/5 rounded-full blur-[120px] pointer-events-none"
      />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-12 gap-20 items-center">
          <div className="lg:col-span-5">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center space-x-5 text-red-600 mb-10"
            >
              <div className="w-16 h-16 bg-red-600 rounded-[1.5rem] flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.3)]">
                <Youtube size={36} className="text-white" />
              </div>
              <span className="font-black tracking-[0.5em] uppercase text-[10px]">Studio Channel</span>
            </motion.div>
            
            <h2 className="text-5xl lg:text-7xl font-black mb-8 leading-[1.05]">
              Master Art From <br /> <span className="text-red-600">Your Living Room</span>
            </h2>
            
            <p className="text-gray-400 text-xl mb-12 leading-relaxed font-medium">
              Join our <span className="text-white">50,000+ members</span> community. Weekly tutorials, live sketching sessions, and craft workshops.
            </p>
            
            <div className="flex items-center space-x-12 mb-16">
               <div className="group cursor-pointer">
                  <div className="flex items-center space-x-3 text-4xl font-black">
                    <Users className="text-[#4ECDC4] group-hover:scale-110 transition-transform" />
                    <span>50K</span>
                  </div>
                  <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mt-2">Loyal Students</p>
               </div>
               <div className="w-px h-12 bg-gray-800"></div>
               <div className="group cursor-pointer">
                  <div className="flex items-center space-x-3 text-4xl font-black text-[#FFE66D]">
                    <Bell className="group-hover:rotate-12 transition-transform" />
                    <span>Daily</span>
                  </div>
                  <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mt-2">Inspirations</p>
               </div>
            </div>

            <motion.a 
              href={channelUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05, translateZ: 20 }}
              className="inline-flex items-center space-x-5 px-12 py-6 bg-red-600 hover:bg-red-700 rounded-[2rem] font-black shadow-3xl shadow-red-600/30 transition-all"
            >
              <span>Subscribe Free</span>
              <ExternalLink size={24} />
            </motion.a>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-8 perspective-1000">
            {featuredVideos.map((video, idx) => (
              <VideoCard key={video.id} video={video} large={idx === 0} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default YouTubeSection;
