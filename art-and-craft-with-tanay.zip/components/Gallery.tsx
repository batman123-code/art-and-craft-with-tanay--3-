
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn, Palette, Layers } from 'lucide-react';
import { GALLERY, PaintSplatterSVG, MandalaSVG } from '../constants';

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<typeof GALLERY[0] | null>(null);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  // Fix: Explicitly cast 'spring' as a literal to satisfy AnimationGeneratorType in Framer Motion variants
  const itemVariants = {
    hidden: { opacity: 0, y: 100, rotateX: 45, scale: 0.8 },
    visible: { 
      opacity: 1, 
      y: 0, 
      rotateX: 0, 
      scale: 1,
      transition: { type: "spring" as const, damping: 20, stiffness: 100 }
    }
  };

  return (
    <section id="gallery" className="py-32 bg-white relative overflow-hidden">
      {/* Depth Decorators */}
      <MandalaSVG color="#9B59B6" className="absolute top-0 right-0 w-[600px] h-[600px] -translate-y-1/2 translate-x-1/2 opacity-5 pointer-events-none" />
      <PaintSplatterSVG color="#FF6B6B" className="absolute bottom-0 left-0 w-96 h-96 opacity-5 pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-24 max-w-3xl mx-auto">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            whileInView={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", duration: 1 }}
            className="w-20 h-20 bg-[#9B59B6]/10 rounded-3xl flex items-center justify-center mx-auto mb-8 text-[#9B59B6] rotate-12"
          >
            <Layers size={32} />
          </motion.div>
          <h2 className="text-5xl md:text-7xl font-bold mb-8 text-[#2C3E50]">The Student <span className="text-[#9B59B6]">Legacy</span></h2>
          <p className="text-gray-500 text-xl leading-relaxed">
            Witness the artistic transformation of our learners from across Kolkata. 
            Every stroke is a step towards mastery.
          </p>
        </div>

        {/* Masonry-like Grid with staggered load */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="columns-1 sm:columns-2 lg:columns-3 gap-10 space-y-10"
        >
          {GALLERY.map((item, idx) => (
            <motion.div
              key={item.id}
              variants={itemVariants}
              whileHover={{ 
                scale: 1.05, 
                rotateY: 5,
                translateZ: 30,
                boxShadow: "0 30px 60px rgba(155, 89, 182, 0.2)"
              }}
              className="relative group cursor-none overflow-hidden rounded-[3rem] bg-gray-50 border border-gray-100 transition-all clickable"
              onClick={() => setSelectedImage(item)}
              style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
            >
              <img 
                src={item.url} 
                alt={item.title} 
                className="w-full object-cover transition-transform duration-1000 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#9B59B6]/95 via-[#9B59B6]/30 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-10">
                <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-[#9B59B6] mb-6 shadow-2xl transform translate-y-10 group-hover:translate-y-0 transition-transform duration-500">
                  <ZoomIn size={28} />
                </div>
                <h4 className="text-white font-black text-3xl mb-2 transform translate-y-10 group-hover:translate-y-0 transition-transform duration-500 delay-75">{item.title}</h4>
                <p className="text-white/80 font-bold uppercase tracking-widest text-xs transform translate-y-10 group-hover:translate-y-0 transition-transform duration-500 delay-150">Art by {item.artist}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mt-24 text-center"
        >
          <button className="px-16 py-6 bg-[#2C3E50] text-white rounded-[2rem] font-bold hover:bg-[#9B59B6] transition-all shadow-2xl shadow-[#9B59B6]/20">
            Discover More Artworks
          </button>
        </motion.div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-6 md:p-12"
            onClick={() => setSelectedImage(null)}
          >
            <motion.button 
              className="absolute top-10 right-10 text-white/50 hover:text-white transition-colors p-4"
              onClick={() => setSelectedImage(null)}
            >
              <X size={48} />
            </motion.button>
            <motion.div 
              initial={{ scale: 0.7, rotateY: 90, opacity: 0 }}
              animate={{ scale: 1, rotateY: 0, opacity: 1 }}
              exit={{ scale: 0.7, rotateY: -90, opacity: 0 }}
              transition={{ type: "spring" as const, damping: 20 }}
              className="max-w-6xl w-full relative"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative rounded-[3rem] overflow-hidden shadow-[0_0_150px_rgba(155,89,182,0.4)]">
                <img src={selectedImage.url} alt={selectedImage.title} className="w-full h-auto max-h-[85vh] object-contain" />
              </div>
              <div className="mt-10 text-center">
                <h3 className="text-4xl font-black text-white mb-3">{selectedImage.title}</h3>
                <p className="text-gray-400 text-xl font-medium">A masterpiece by <span className="text-[#9B59B6] font-black">{selectedImage.artist}</span></p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Gallery;
